/*@ Extern Coq (nil : {A} -> list A)
               (cons : {A} -> A -> list A -> list A)
               (app : {A} -> list A -> list A -> list A)
               (rev : {A} -> list A -> list A)
               (Zlength: {A} -> list A -> Z)
 */